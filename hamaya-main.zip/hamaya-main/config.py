from mody import Mody
Token = Mody.ELHYBA
